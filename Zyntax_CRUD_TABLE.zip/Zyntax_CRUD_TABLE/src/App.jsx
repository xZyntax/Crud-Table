import Table from './Components/Table'
import React from 'react'

function App() {
  return (
    <>
    <Table  />
    </>
  )
}

export default App
import React, { useState, useEffect } from 'react';
import './Table-style/Table.css';

const Table = () => {
  const [data, setData] = useState([]);
  const [formData, setFormData] = useState({ name: '', age: '' });

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((response) => response.json())
      .then((json) => setData(json));
  }, []);
  // MODIFY VALUE
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  // ADD FUNCTION
  const handleAdd = () => {
    const newId = data.length + 1;
    const newData = [...data, { id: newId, ...formData }];
    setData(newData);
    setFormData({ name: '', age: '', address:'' });
  };
 // EDIT FUNCTION 
  const handleEdit = (id, newData) => {
    const updatedData = data.map((item) => {
      if (item.id === id) {
        return { ...item, ...newData };
      } else {
        return item;
      }
    });
    setData(updatedData);
  };
  // DELETE FUNCTION
  const handleDelete = (id) => {
    fetch(`https://jsonplaceholder.typicode.com/users/${id}`, {
      method: 'DELETE'
    })
      .then((response) => response.json())
      .then(() => {
        const filteredData = data.filter((item) => item.id !== id);
        setData(filteredData);
      });
  };
 // SEARCH FUNCTION
  const handleSearch = (e) => {
    const keyword = e.target.value;
    if (keyword !== '') {
      const filteredData = data.filter(
        (item) =>
          item.name.toLowerCase().includes(keyword.toLowerCase()) ||
          item.username.toLowerCase().includes(keyword.toLowerCase()) ||
          item.email.toLowerCase().includes(keyword.toLowerCase()) ||
          item.address.city.toLowerCase().includes(keyword.toLowerCase())
      );
      setData(filteredData);
    } else {
      fetch('https://jsonplaceholder.typicode.com/users')
        .then((response) => response.json())
        .then((json) => setData(json));
    }
  };
  

  return (
    <div>
       <div className="search">
        <input type="text" placeholder="Search" onChange={handleSearch} />
      </div>
  
      <table>

        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Year Level</th>
            <th>Course</th>
            <th>Date of Birth</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        {/* MINAP KO YUNG API BAGUHIN MO NALANG GAMIT API MO  */}
        <tbody>
          {data.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.name}</td>
              <td>{item.username}</td>
              <td>{item.email}</td>
              <td>{item.address.city}</td>
              <td>
                <button
                  className="edit"
                  onClick={() =>
                    handleEdit(item.id, {
                      name: prompt('Enter new name', item.name),
                      username: prompt('Enter new username', item.username),
                      email: prompt('Enter new email', item.email),
                      city: prompt('Enter new email', item.email)
                    })
                  }
                >
                  Edit
                </button>
              </td>
              <td>
                <button onClick={() => handleDelete(item.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="form">
        <input
          type="text"
          placeholder="Name"
          name="name"
          value={formData.name}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Year Levell"
          name="username"
          value={formData.username}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Course"
          name="email"
          value={formData.email}
          onChange={handleChange}
        />
        {/* BAKIT GANITO ? MAY BUG KASE DI NAWAWALA YUNG VALUE NG INPUT AFTER MAG ADD TAPOS DI NAG AADD VALUE PERO OK NA SHA, NAKA OBJECT YUNG ADDRESS  */}
        <input
  type="text"
  placeholder="Date of Birth"
  name="address"
  value={formData.address ? formData.address.city : ''}
  onChange={(e) =>
    setFormData({
      ...formData,
      address: { ...formData.address, city: e.target.value }
    })
  }
/>

        <button onClick={handleAdd}>Add</button>
      </div>
    </div>
  );
};

export default Table;
